Commodity Open Task 2 - experimental boosted candidate

No win or prize qualification is claimed. Not runtime-tested against the real kit or pack.
Use only the files inside this ZIP, not earlier generated candidates.

1. Extract this ZIP into the latest kit's template folder, beside run.py.
2. Activate the latest kit's Python 3.13 environment.
3. Set SWING_PACK_ROOT to the extracted v2.1 directory.
4. Run: bash test_boosted.sh validate
5. Inspect/upload boosted_preJune_validation.json BEFORE running holdout.
6. If proceeding: bash test_boosted.sh holdout
   This backs up model.py with a unique name, installs the candidate, runs learning and
   frozen copies with horizons 3,5, and scores them into a new timestamped directory.

Design:
- HistGradientBoostingClassifier, shared asset/horizon model; three outcome classes.
- Published daily trend/range/volatility/expiry features and as-of cross-asset momentum.
- Training feature clocks conservatively include the maximum publication timestamp of
  all contracts for the asset/session and previous contributing sessions.
- Explicit nanosecond conversion for datetime indices.
- Select an absolute cutoff using 2024 only, with minimum selected sample counts.
- Select success-calibration learning strength using 2025 only; zero learning is allowed
  to win rather than forcing harmful updates.
- Audit Jan-May 2026 AFTER those selections, without selecting on its results.
- Fit final classifier on completed pre-June examples only.
- Static selector chooses both signal eligibility and one of horizons 3/5; updates cannot
  change which keys are issued, preserving matching learning/frozen opportunities.
- Actual online calibration learns only from own nonambiguous outcomes delivered to update.
- Magnitude intervals use completed, successful historical windows; no incomplete online
  excursions are treated as final magnitude labels.
- No direct pack-file reads, external services, pretrained weights or edited prediction files.

Limitations:
- Validation is a daily-bar, conservatively full-window-delayed learning proxy. Official
  updates can arrive earlier and final scoring uses available ticks. It is not an exact
  historical replay of the kit loop or the official score.
- Selection searches several settings and can overfit. It does not estimate official
  confidence intervals or check every award condition/null; the official scorer does.
- 2026 audit results are pre-holdout diagnostics, not unseen forward performance.
- If eta is zero or audit direction/learning evidence is weak, do not call this prize-ready.
- Band outputs are empirical p10/median/p90; expected_pct is the median point forecast,
  as in the shipped template, not a separately fitted conditional mean.
- Full-history feature rebuilding favors correctness over speed; runtime is unmeasured.
- Reproduction, pinned dependencies, licensing, memo, repository layout and final runner
  horizon defaults must be completed separately before submission.
- run.py defaults to 5,10. This model REQUIRES 3,5; final submission/reproduction must
  enforce those horizons consistently, not rely only on an interactive command.

Local checks performed:
Python syntax; synthetic HGB fit/prediction; selector support checks; delayed calibration
simulation; zero-eta paired equality; mocked predict/update interface. Real kit not installed
in the test environment, real data not available. No official score has been computed here.
