#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
: "${SWING_PACK_ROOT:?Set SWING_PACK_ROOT to the extracted v2.1 folder first}"
test -f "$SWING_PACK_ROOT/MANIFEST.json" || { echo "Pack manifest not found"; exit 1; }
test -f run.py || { echo "Extract this package into template/, beside run.py"; exit 1; }
case "${1:-validate}" in
  validate)
    python boosted_model.py --pack "$SWING_PACK_ROOT" --out boosted_preJune_validation.json
    ;;
  holdout)
    test -f boosted_preJune_validation.json || { echo "Run validate first"; exit 1; }
    python - <<'PY'
import ast
from pathlib import Path
from datetime import datetime
candidate=Path("boosted_model.py").read_bytes()
ast.parse(candidate.decode())
backup=Path("model_before_boosted_"+datetime.now().strftime("%Y%m%d_%H%M%S_%f")+".py")
backup.write_bytes(Path("model.py").read_bytes())
Path("model.py").write_bytes(candidate)
print("Original model saved as", backup.name)
PY
    DEST="boosted_predictions_$(date +%Y%m%d_%H%M%S)"
    mkdir "$DEST"
    python run.py --pack "$SWING_PACK_ROOT" --challenge 2 --period holdout --horizons 3,5 --out "$DEST"
    python run.py --pack "$SWING_PACK_ROOT" --challenge 2 --period holdout --horizons 3,5 --frozen --out "$DEST"
    python ../tools/score_holdout.py --pack "$SWING_PACK_ROOT" --predictions "$DEST/" --challenge 2
    echo "Upload $DEST/report_2_holdout.json"
    ;;
  *) echo "Use: bash test_boosted.sh validate   OR   bash test_boosted.sh holdout"; exit 1 ;;
esac
